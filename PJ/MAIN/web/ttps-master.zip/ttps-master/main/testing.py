import ml_model

x = [-1.380899, -0.638146, 1.315741, -1.325480, -0.231486, 0.081364, -0.319305, 0.380]
print(ml_model.logic_layer(x))
input()
input()
input()